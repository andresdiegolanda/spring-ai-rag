import os
from langchain import OpenAI
from langchain.embeddings import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.document_loaders import TextLoader
from langchain.agents import Tool, initialize_agent, AgentType
from langchain.chains import RetrievalQA
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize the OpenAI model
openai_api_key = os.getenv("OPENAI_API_KEY")
llm = OpenAI(temperature=0, openai_api_key=openai_api_key)

# Step 1: Load the document
loader = TextLoader('security_issues_simulation_with_names.txt')
documents = loader.load_and_split()

# Step 2: Generate embeddings for the document chunks
embeddings = OpenAIEmbeddings(openai_api_key=openai_api_key)

# Step 3: Create a FAISS vector store for storing and retrieving embeddings
vector_store = FAISS.from_documents(documents, embeddings)

# Step 4: Set up the FAISS retriever as a tool
retriever = vector_store.as_retriever()

# Step 5: Create a RetrievalQA chain
qa_chain = RetrievalQA.from_chain_type(
    llm=llm,
    chain_type="stuff",
    retriever=retriever,
    return_source_documents=True
)

# Step 6: Define the tool for the agent to use (using FAISS retriever)
tools = [
    Tool(
        name="Document Retrieval Tool",
        func=qa_chain.invoke,  # Use invoke here instead of run
        description="Useful for answering questions based on the security issues document."
    )
]


# Step 7: Initialize the agent
agent = initialize_agent(
    tools=tools,
    llm=llm,
    agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,  # A basic agent that reacts to descriptions
    verbose=True  # Enables more detailed logging
)

# Function to ask the agent a question
def ask_agent(question):
    response = agent.run(question)
    return response

if __name__ == "__main__":
    print("LangChain Security Issue QA Agent")
    while True:
        query = input("Ask a question: ")
        if query.lower() in ["exit", "quit"]:
            break
        answer = ask_agent(query)
        print(f"Answer: {answer}")
